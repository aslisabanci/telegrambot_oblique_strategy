# telegrambot_oblique_strategy
My humble telegram bot that sends random "oblique strategies" at random intervals, for spontaneous inspiration
